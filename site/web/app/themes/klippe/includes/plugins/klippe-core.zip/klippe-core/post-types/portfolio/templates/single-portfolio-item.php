<?php

get_header();

klippe_mikado_get_title();

do_action('klippe_mikado_before_main_content');

klippe_core_get_single_portfolio();

get_footer();