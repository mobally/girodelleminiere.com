<?php

include_once MIKADO_CORE_SHORTCODES_PATH . '/video-button/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH . '/video-button/video-button.php';