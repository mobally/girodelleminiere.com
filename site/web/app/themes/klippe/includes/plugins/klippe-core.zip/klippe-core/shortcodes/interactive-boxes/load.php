<?php

include_once MIKADO_CORE_SHORTCODES_PATH . '/interactive-boxes/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH . '/interactive-boxes/interactive-boxes.php';