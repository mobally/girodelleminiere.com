<?php

include_once MIKADO_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-standard/functions.php';
include_once MIKADO_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-standard/header-standard.php';