<div class="mkdf-post-info-category">
    <?php the_category(', '); ?>
</div>