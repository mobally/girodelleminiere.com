<?php

do_action('klippe_mikado_style_dynamic');