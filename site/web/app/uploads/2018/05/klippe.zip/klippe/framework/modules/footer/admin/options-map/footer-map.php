<?php

if ( ! function_exists( 'klippe_mikado_footer_options_map' ) ) {
	function klippe_mikado_footer_options_map() {

		klippe_mikado_add_admin_page(
			array(
				'slug'  => '_footer_page',
				'title' => esc_html__( 'Footer', 'klippe' ),
				'icon'  => 'fa fa-sort-amount-asc'
			)
		);

		$footer_panel = klippe_mikado_add_admin_panel(
			array(
				'title' => esc_html__( 'Footer', 'klippe' ),
				'name'  => 'footer',
				'page'  => '_footer_page'
			)
		);

		klippe_mikado_add_admin_field(
			array(
				'type'          => 'yesno',
				'name'          => 'footer_in_grid',
				'default_value' => 'yes',
				'label'         => esc_html__( 'Footer in Grid', 'klippe' ),
				'description'   => esc_html__( 'Enabling this option will place Footer content in grid', 'klippe' ),
				'parent'        => $footer_panel
			)
		);

		klippe_mikado_add_admin_field(
			array(
				'type'          => 'yesno',
				'name'          => 'show_footer_top',
				'default_value' => 'yes',
				'label'         => esc_html__( 'Show Footer Top', 'klippe' ),
				'description'   => esc_html__( 'Enabling this option will show Footer Top area', 'klippe' ),
				'parent'        => $footer_panel,
			)
		);
		
		$show_footer_top_container = klippe_mikado_add_admin_container(
			array(
				'name'       => 'show_footer_top_container',
				'parent'     => $footer_panel,
				'dependency' => array(
					'show' => array(
						'show_footer_top' => 'yes'
					)
				)
			)
		);

		klippe_mikado_add_admin_field(
			array(
				'type'          => 'select',
				'name'          => 'footer_top_columns',
				'parent'        => $show_footer_top_container,
				'default_value' => '4',
				'label'         => esc_html__( 'Footer Top Columns', 'klippe' ),
				'description'   => esc_html__( 'Choose number of columns for Footer Top area', 'klippe' ),
				'options'       => array(
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4'
				)
			)
		);

		klippe_mikado_add_admin_field(
			array(
				'type'          => 'select',
				'name'          => 'footer_top_columns_alignment',
				'default_value' => 'left',
				'label'         => esc_html__( 'Footer Top Columns Alignment', 'klippe' ),
				'description'   => esc_html__( 'Text Alignment in Footer Columns', 'klippe' ),
				'options'       => array(
					''       => esc_html__( 'Default', 'klippe' ),
					'left'   => esc_html__( 'Left', 'klippe' ),
					'center' => esc_html__( 'Center', 'klippe' ),
					'right'  => esc_html__( 'Right', 'klippe' )
				),
				'parent'        => $show_footer_top_container,
			)
		);

		klippe_mikado_add_admin_field(
			array(
				'name'        => 'footer_top_background_color',
				'type'        => 'color',
				'label'       => esc_html__( 'Background Color', 'klippe' ),
				'description' => esc_html__( 'Set background color for top footer area', 'klippe' ),
				'parent'      => $show_footer_top_container
			)
		);

		klippe_mikado_add_admin_field(
			array(
				'type'          => 'yesno',
				'name'          => 'show_footer_bottom',
				'default_value' => 'yes',
				'label'         => esc_html__( 'Show Footer Bottom', 'klippe' ),
				'description'   => esc_html__( 'Enabling this option will show Footer Bottom area', 'klippe' ),
				'parent'        => $footer_panel,
			)
		);

		$show_footer_bottom_container = klippe_mikado_add_admin_container(
			array(
				'name'            => 'show_footer_bottom_container',
				'parent'          => $footer_panel,
				'dependency' => array(
					'show' => array(
						'show_footer_bottom'  => 'yes'
					)
				)
			)
		);

		klippe_mikado_add_admin_field(
			array(
				'type'          => 'select',
				'name'          => 'footer_bottom_columns',
				'default_value' => '2',
				'label'         => esc_html__( 'Footer Bottom Columns', 'klippe' ),
				'description'   => esc_html__( 'Choose number of columns for Footer Bottom area', 'klippe' ),
				'options'       => array(
					'1' => '1',
					'2' => '2',
					'3' => '3'
				),
				'parent'        => $show_footer_bottom_container,
			)
		);

		klippe_mikado_add_admin_field(
			array(
				'name'        => 'footer_bottom_background_color',
				'type'        => 'color',
				'label'       => esc_html__( 'Background Color', 'klippe' ),
				'description' => esc_html__( 'Set background color for bottom footer area', 'klippe' ),
				'parent'      => $show_footer_bottom_container
			)
		);
	}

	add_action( 'klippe_mikado_options_map', 'klippe_mikado_footer_options_map', 11 );
}