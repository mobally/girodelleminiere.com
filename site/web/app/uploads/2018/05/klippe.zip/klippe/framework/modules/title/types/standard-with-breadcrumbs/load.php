<?php

include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/title/types/standard-with-breadcrumbs/functions.php';