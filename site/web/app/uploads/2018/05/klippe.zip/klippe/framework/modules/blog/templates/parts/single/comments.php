<?php
if(klippe_mikado_show_comments()){
    comments_template('', true);
}